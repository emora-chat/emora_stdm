
class MissingStateException(Exception):
    pass

class MissingOntologyException(Exception):
    pass

class MissingKnowledgeException(Exception):
    pass

class MissingErrorStateException(Exception):
    pass